package com.example.practicaspring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class PoblacioController {
    private final PoblacioService poblacioService;

    @Autowired
    public PoblacioController(PoblacioService poblacioService) {
        this.poblacioService = poblacioService;
    }

    @GetMapping("/poblacio")
    public String getPoblacioData(Model model) {
        List<PoblacioData> poblacioData = poblacioService.getPoblacioData();
        model.addAttribute("poblacioData", poblacioData);
        return "poblacioDataView";
    }
}

