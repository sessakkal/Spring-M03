package com.example.practicaspring;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PoblacioData {
    private String any;
    private String codi;
    private String literal;
    private String homes_de_0_a_14_anys;
    private String homes_de_15_a_64_anys;
    private String homes_de_65_anys_i_m_s;
    private String dones_de_0_a_14_anys;
    private String dones_de_15_a_64_anys;
    private String dones_de_65_anys_i_m_s;
    private String total_de_0_a_14_anys;
    private String total_de_15_a_64_anys;
    private String total_de_65_anys_i_m_s;

    // Agrega constructores, getters y setters según sea necesario

    public String getAny() {
        return any;
    }

    public void setAny(String any) {
        this.any = any;
    }

    public String getCodi() {
        return codi;
    }

    public void setCodi(String codi) {
        this.codi = codi;
    }

    public String getLiteral() {
        return literal;
    }

    public void setLiteral(String literal) {
        this.literal = literal;
    }

    public String getHomes_de_0_a_14_anys() {
        return homes_de_0_a_14_anys;
    }

    public void setHomes_de_0_a_14_anys(String homes_de_0_a_14_anys) {
        this.homes_de_0_a_14_anys = homes_de_0_a_14_anys;
    }

    public String getHomes_de_15_a_64_anys() {
        return homes_de_15_a_64_anys;
    }

    public void setHomes_de_15_a_64_anys(String homes_de_15_a_64_anys) {
        this.homes_de_15_a_64_anys = homes_de_15_a_64_anys;
    }

    public String getHomes_de_65_anys_i_m_s() {
        return homes_de_65_anys_i_m_s;
    }

    public void setHomes_de_65_anys_i_m_s(String homes_de_65_anys_i_m_s) {
        this.homes_de_65_anys_i_m_s = homes_de_65_anys_i_m_s;
    }

    public String getDones_de_0_a_14_anys() {
        return dones_de_0_a_14_anys;
    }

    public void setDones_de_0_a_14_anys(String dones_de_0_a_14_anys) {
        this.dones_de_0_a_14_anys = dones_de_0_a_14_anys;
    }

    public String getDones_de_15_a_64_anys() {
        return dones_de_15_a_64_anys;
    }

    public void setDones_de_15_a_64_anys(String dones_de_15_a_64_anys) {
        this.dones_de_15_a_64_anys = dones_de_15_a_64_anys;
    }

    public String getDones_de_65_anys_i_m_s() {
        return dones_de_65_anys_i_m_s;
    }

    public void setDones_de_65_anys_i_m_s(String dones_de_65_anys_i_m_s) {
        this.dones_de_65_anys_i_m_s = dones_de_65_anys_i_m_s;
    }

    public String getTotal_de_0_a_14_anys() {
        return total_de_0_a_14_anys;
    }

    public void setTotal_de_0_a_14_anys(String total_de_0_a_14_anys) {
        this.total_de_0_a_14_anys = total_de_0_a_14_anys;
    }

    public String getTotal_de_15_a_64_anys() {
        return total_de_15_a_64_anys;
    }

    public void setTotal_de_15_a_64_anys(String total_de_15_a_64_anys) {
        this.total_de_15_a_64_anys = total_de_15_a_64_anys;
    }

    public String getTotal_de_65_anys_i_m_s() {
        return total_de_65_anys_i_m_s;
    }

    public void setTotal_de_65_anys_i_m_s(String total_de_65_anys_i_m_s) {
        this.total_de_65_anys_i_m_s = total_de_65_anys_i_m_s;
    }
}
