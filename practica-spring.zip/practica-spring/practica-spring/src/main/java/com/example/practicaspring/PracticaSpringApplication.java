package com.example.practicaspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticaSpringApplication.class, args);
	}

}
