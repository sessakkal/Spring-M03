package com.example.practicaspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
