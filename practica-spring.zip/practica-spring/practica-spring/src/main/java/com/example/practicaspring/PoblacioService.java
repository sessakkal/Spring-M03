package com.example.practicaspring;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Service
public class PoblacioService {
    private final RestTemplate restTemplate = new RestTemplate();
    private final String apiUrl = "https://analisi.transparenciacatalunya.cat/resource/b4rr-d25b.json";

    public List<PoblacioData> getPoblacioData() {
        PoblacioData[] poblacioDataArray = restTemplate.getForObject(apiUrl, PoblacioData[].class);
        return Arrays.asList(poblacioDataArray);
    }
}

